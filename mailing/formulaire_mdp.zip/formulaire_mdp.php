<? 
$title = "Mdp oublié";
include("../includes/head.php");

?>

<body>


<main>

<form method = "POST" action = "envoi_mail_pwd_oubli.php">

<input type = "email" name = "email" placeholder = "Entrez votre email">
<input type = "submit">


</form>

</main>


</body>